-- 3. 아래 문항을 코딩하세요 지시된 사항외에 나머지는 자유롭게 하세요
-- 3-1) 부서별 급여 합계 구합니다.(group by dno)  
-- 위에서 구한 부서별 급여합계를 모두 더한 총합도 구합니다.
-- 파이프라인 형제 집계를 사용하세요

POST /employee/_search
{
  "size": 0,
  "aggs": {
    "tdno": {
      "terms": {
        "field": "dno"
      },
      "aggs": {
        "ssum": {
          "sum": {
            "field": "salary"
          }
        }
      }
    },
    "total":{
      "sum_bucket": {
        "buckets_path": "tdno>ssum"
      }
    }
  }
}