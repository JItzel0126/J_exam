/**
 * 
 */
package egovframework.example.exam4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

/**
 * @author user
 * @Log4j2
 * @Controller
 * public class DeptController {
 * //        서비스 가져오기
 * 	  @Autowired
 *     private DeptService deptService; 
 * ...
 *     }
 */
public class B {

}
