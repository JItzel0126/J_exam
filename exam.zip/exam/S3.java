/**
 * 
 */
package exam;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @author user 3. 첫줄에 숫자의 총개수 N이 입력됩니다.
 * 2줄에 N개의 숫자가 랜덤하게 입력됩니다.
 * 오름차순 정렬해서 화면에
 * 표시하는 코드를 작성하세요 입력:
 * 5 5 2 3 4 1 출력 1 2 3 4 5
 */
public class S3 {
	public static void main(String[] args) {
//		값 입력
		Scanner sc = new Scanner(System.in);
//		1열 정수로 입력받음
		int n1 = sc.nextInt();
//		2열 Line로 입력받음
		sc.nextLine();
//		2열 입력 배열로 변경, " " 기준으로 스플릿
		String[] b = sc.nextLine().split(" ");
//		1열 입력받은 n1만큼 배열 방번호 선언
		int[] num = new int[n1];
//		2열 입력 문자를 정수로 바꿔서 num 배열에 순차적으로 대입
		for (int i = 0; i < n1; i++) {
			num[i]=Integer.parseInt(b[i]);
		}
//		num 배열을 오름차순으로 변경
		Arrays.sort(num);
//		배열 반복문, 오름차순으로 변경 된 num 배열을 순차적으로 화면 출력
		for(int i = 0; i<n1; i++) {
			System.out.println(num[i]+" ");
		}	
	}
}
