# 2. hello 을 화면에 표시하려고 합니다. 코드를 작성하세요.

print("hello")

def hello():
    print("hello")

hello()


def hi(name):
    print(name)

hi("hello")

