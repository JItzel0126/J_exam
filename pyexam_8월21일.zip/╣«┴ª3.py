# 3. https://www.saucedemo.com/ 접속 및 로그인후 나오는
# 첫페이지에서 상품설명을 모두 크롤링해서 화면에 표시하는 코딩을 하세요

import json
import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager

def write(name, value):
    with open(name, "w", encoding="utf=8") as f:
        json.dump(value, f, ensure_ascii=False, indent=4)

# 웹브라우저 설치, 옵션
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=Options())
# 로그인 페이지 접속
driver.get("https://www.saucedemo.com/")

driver.find_element(By.ID, "user-name").send_keys("standard_user")
driver.find_element(By.CSS_SELECTOR, "#password").send_keys("secret_sauce")
driver.find_element(By.CSS_SELECTOR, "#login-button").click()

time.sleep(1)

items = driver.find_elements(By.CSS_SELECTOR, ".inventory_item_desc")


# 화면표시
for i in range(len(items)):
    y=items[i].text
    print("상품설명:",y)
    print()

# json 파일 만들기
# j=[]
# for item in items:
#     j.append({
#         "item_desc" : item.text
#     })
#
# write("상품명.json", j)

driver.quit()


